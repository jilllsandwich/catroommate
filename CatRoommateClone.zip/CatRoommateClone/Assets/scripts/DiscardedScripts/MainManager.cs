﻿using System.Collections;
using System.Collections.Generic;
using JetBrains.Annotations;
using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class MainManager : MonoBehaviour
{
    //public questionManager[] questions; 
 
    //private static List<questionManager> _unansweredQuestions;

   // private questionManager currentQuestion; 

    void Start()
    {
       // if (_unansweredQuestions == null || _unansweredQuestions.Count == 0)
      //  {
       //     _unansweredQuestions = questions.ToList<questionManager>();
      //  }
        
        
    }
}
