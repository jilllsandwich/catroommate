﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

    //HOW I THINK IT SHOULD WORK??
    //bools
    //trueButton
    //falseButton
    //if trueButton is clicked on (getkeydown/onclickenter) then cat makes x face
    //if false button is clicked on then cat makes x face
    //if button is clicked, next question appears and cat face is changed
    //if number of trueButton clicks exceeds falseButton clicks, you win, otherwise vice versa you lose

    public Sprite[] sprites;


public class HelpFreeScript : MonoBehaviour
{
    
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
